library(MetDNA2)
runMetDNA2(
  path_pos = "/share/home/zhuzhengjiang/data/20220412_reprocess_biological_samples/NIST_urine_neg",
  metdna_version = "version2",
  polarity = "negative",
  instrument = "SciexTripleTOF",
  column = "hilic",
  ce = "30",
  method_lc = "Amide23min",
  correct_p = FALSE,
  extension_step = "2",
  comp_group = c("neg_only_full_DDA", "QC"),
  species = "hsa",
  dir_GenForm = "/share/home/zhuzhengjiang/share/bin",
  p_cutoff = 0.050000,
  fc_cutoff = 1.000000,
  is_rt_calibration = TRUE,
  thread = 10,
  is_webserver = FALSE,
  is_rm_intermediate_data = FALSE,
  is_plot_ms2 = TRUE)

