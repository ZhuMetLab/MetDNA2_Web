#!/bin/bash
#SBATCH -J MetDNA2
###指定任务队列，默认使用normal
#SBATCH -p compute_cpu
###申请1个节点，单节点任务可以省略不写
###SBATCH -N 1
###每个节点分配20个MPI进程，即cpu核心数。
#SBATCH --ntasks-per-node=20
###一共跑节点数x进程数个进程。也可以省略“-N”和” --ntasks-per-node”参数，这样任务会优先填满一个节点，不会平均分散在几个节点上。
#SBATCH -n 20
###每个节点申请4个gpu，cpu任务请注释掉
###SBATCH --gres=gpu:4
#SBATCH --get-user-env
###脚本错误输出
#SBATCH -e job-%j.err
###脚本输出
#SBATCH -o job-%j.out
###进入提交任务时所在目录
cd $SLURM_SUBMIT_DIR

###加载环境变量，根据实际使用的程序修改
module load gnu8/8.3.0
module load miniconda3

####下面是要执行的程序
echo "The nodes allocated to the job is $SLURM_JOB_NODELIST ."
echo "The number of processors on this node allocated to the job is $SLURM_JOB_CPUS_PER_NODE ."
echo "Number of tasks to be initiated on each node is $SLURM_TASKS_PER_NODE ."

source activate RTestZZW
result=$(which R)
echo "Using R from $result ."

date -R

Rscript run.R

#mpirun不加参数会默认以80个进程运行
#mpirun hostname
#sleep10
echo Completed!
date -R
